# FORESIGHT — Demand & Inventory Intelligence Platform

A static 12-page analytics dashboard built from the Online Retail II transaction
dataset (Dec 2009 – Dec 2011), ready to deploy on Netlify.

## What's inside
- `index.html` — page shell + sidebar nav for all 12 dashboards
- `style.css` — design system (navy/amber/teal palette, Space Grotesk + IBM Plex)
- `app.js` — renders all charts/tables (Chart.js, loaded via CDN)
- `data.js` — pre-computed aggregates from the dataset, embedded as a JS object
  (no backend/database needed — everything is static)
- `netlify.toml` — deploy config

## Deploy to Netlify (pick one)

**Option A — Drag and drop (fastest, no account setup beyond signing in)**
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page
3. Netlify gives you a live URL immediately

**Option B — Netlify CLI**
```
npm install -g netlify-cli
cd this-folder
netlify deploy --prod
```

**Option C — Git-based (auto-redeploys on push)**
1. Push this folder to a GitHub repo
2. In Netlify: "Add new site" → "Import an existing project" → pick the repo
3. Build command: leave blank · Publish directory: `.`

## Updating the data
Re-run the aggregation script against a new copy of `Dataset.xlsx` and replace
`data.js` — no other file needs to change.

## Notes on the data
- Inventory, Stockout Risk, Overstock and Promotion pages use **modeled/proxy
  metrics** because the source dataset is transactional only (no live stock
  feed or promo flag). This is disclosed in-app on each relevant page.
- Category is derived from keyword rules over the product description field,
  since the dataset has no category column.
