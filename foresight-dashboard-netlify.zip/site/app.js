(function(){
  const D = window.DASHBOARD_DATA;

  const PALETTE = {
    amber:'#E8A33D', amberDeep:'#C97F1E', teal:'#2E9C93', coral:'#D9605A',
    violet:'#7C6FE0', navy:'#2A4384', navySoft:'#5B6478', line:'#E2E5EE',
    good:'#2E9C63', risk:'#D9605A'
  };
  const SERIES = [PALETTE.amber, PALETTE.teal, PALETTE.violet, PALETTE.coral, PALETTE.navy];

  Chart.defaults.font.family = "'IBM Plex Sans', sans-serif";
  Chart.defaults.font.size = 11.5;
  Chart.defaults.color = '#5B6478';
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.legend.labels.boxWidth = 7;

  function fmtMoney(v){
    if (v >= 1e6) return '£' + (v/1e6).toFixed(2) + 'M';
    if (v >= 1e3) return '£' + (v/1e3).toFixed(1) + 'K';
    return '£' + Math.round(v);
  }
  function fmtNum(v){
    return Number(v).toLocaleString('en-GB');
  }
  const gridOpt = { color:'#EEF0F6' };

  // ---------------- Navigation ----------------
  const pages = document.querySelectorAll('.page');
  const links = document.querySelectorAll('.nav-link');
  const rendered = {};

  function showPage(id){
    pages.forEach(p => p.classList.toggle('active', p.id === 'page-'+id));
    links.forEach(l => l.classList.toggle('active', l.dataset.page === id));
    if (!rendered[id] && RENDERERS[id]) { RENDERERS[id](); rendered[id] = true; }
    document.getElementById('sidebar').classList.remove('open');
    window.scrollTo(0,0);
  }
  links.forEach(l => l.addEventListener('click', () => {
    location.hash = l.dataset.page;
    showPage(l.dataset.page);
  }));
  document.getElementById('menuBtn').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });

  // ---------------- KPI helper ----------------
  function kpiCard(label, value, foot, cls){
    return `<div class="kpi ${cls||''}">
      <div class="label">${label}</div>
      <div class="value">${value}</div>
      ${foot ? `<div class="foot">${foot}</div>` : ''}
    </div>`;
  }

  function tableHTML(headers, rows){
    let h = '<table class="data-table"><thead><tr>' +
      headers.map(x => `<th class="${x.num?'num':''}">${x.label}</th>`).join('') +
      '</tr></thead><tbody>';
    rows.forEach(r => {
      h += '<tr>' + r.map((c,i) => `<td class="${headers[i].num?'num':''} ${headers[i].wrap?'desc-cell':''}">${c}</td>`).join('') + '</tr>';
    });
    h += '</tbody></table>';
    return h;
  }

  // ================= RENDERERS =================
  const RENDERERS = {};

  RENDERERS.executive = function(){
    const k = D.executive.kpis;
    document.getElementById('exec-kpis').innerHTML =
      kpiCard('Total Revenue', fmtMoney(k.total_revenue), `${fmtNum(k.total_orders)} orders`, '') +
      kpiCard('Avg Order Value', '£'+k.avg_order_value.toFixed(2), '', 'teal') +
      kpiCard('Customers', fmtNum(k.total_customers), `${k.countries_served} countries`, 'violet') +
      kpiCard('Units Sold', fmtNum(k.total_quantity), `${fmtNum(k.products_sold)} SKUs`, 'coral') +
      kpiCard('Top Market', k.top_country, 'by revenue', '');

    const m = D.executive.monthly_trend;
    new Chart(document.getElementById('exec-trend'), {
      type:'bar',
      data:{
        labels: m.map(r=>r.YearMonth),
        datasets:[
          {type:'line', label:'Revenue', data:m.map(r=>r.Revenue), borderColor:PALETTE.amberDeep, backgroundColor:PALETTE.amberDeep, yAxisID:'y', tension:.3, pointRadius:2, borderWidth:2.2},
          {type:'bar', label:'Orders', data:m.map(r=>r.Orders), backgroundColor:'rgba(124,111,224,.35)', yAxisID:'y1', borderRadius:3}
        ]
      },
      options:{
        responsive:true, maintainAspectRatio:false,
        scales:{
          y:{position:'left', grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}},
          y1:{position:'right', grid:{display:false}, ticks:{callback:v=>fmtNum(v)}},
          x:{grid:{display:false}, ticks:{maxRotation:60,minRotation:60}}
        },
        plugins:{legend:{position:'top', align:'end'}}
      }
    });

    const y = D.executive.yearly_revenue;
    new Chart(document.getElementById('exec-yearly'), {
      type:'bar',
      data:{labels:Object.keys(y), datasets:[{label:'Revenue', data:Object.values(y), backgroundColor:[PALETTE.navy, PALETTE.amber], borderRadius:6, maxBarThickness:90}]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });
  };

  RENDERERS.sales = function(){
    const c = D.sales.by_country;
    new Chart(document.getElementById('sales-country'), {
      type:'bar',
      data:{labels:c.map(r=>r.Country), datasets:[{label:'Revenue', data:c.map(r=>r.Revenue), backgroundColor:PALETTE.teal, borderRadius:4}]},
      options:{indexAxis:'y', responsive:true, maintainAspectRatio:false,
        scales:{x:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, y:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });

    const w = D.sales.by_weekday;
    new Chart(document.getElementById('sales-weekday'), {
      type:'bar',
      data:{labels:Object.keys(w), datasets:[{label:'Revenue', data:Object.values(w), backgroundColor:PALETTE.violet, borderRadius:6}]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });

    const h = D.sales.by_hour;
    new Chart(document.getElementById('sales-hour'), {
      type:'line',
      data:{labels:Object.keys(h).map(x=>x+':00'), datasets:[{label:'Revenue', data:Object.values(h), borderColor:PALETTE.amberDeep, backgroundColor:'rgba(232,163,61,.15)', fill:true, tension:.35, pointRadius:2}]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });

    const d = D.sales.daily_trend;
    new Chart(document.getElementById('sales-daily'), {
      type:'line',
      data:{labels:d.map(r=>r.Date), datasets:[{label:'Revenue', data:d.map(r=>r.Revenue), borderColor:PALETTE.coral, borderWidth:1.3, pointRadius:0, tension:.2}]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}, ticks:{maxTicksLimit:8}}},
        plugins:{legend:{display:false}}}
    });
  };

  RENDERERS.product = function(){
    document.getElementById('product-top-rev').innerHTML = tableHTML(
      [{label:'Code'},{label:'Product', wrap:true},{label:'Revenue', num:true}],
      D.product.top_by_revenue.map(r => [r.StockCode, r.Description, fmtMoney(r.Revenue)])
    );
    document.getElementById('product-top-qty').innerHTML = tableHTML(
      [{label:'Code'},{label:'Product', wrap:true},{label:'Units', num:true}],
      D.product.top_by_quantity.map(r => [r.StockCode, r.Description, fmtNum(r.Qty)])
    );
    document.getElementById('product-bottom').innerHTML = tableHTML(
      [{label:'Code'},{label:'Product', wrap:true},{label:'Revenue', num:true},{label:'Orders', num:true}],
      D.product.bottom_performers.map(r => [r.StockCode, r.Description, fmtMoney(r.Revenue), r.Orders])
    );
  };

  RENDERERS.category = function(){
    const c = D.category.summary;
    new Chart(document.getElementById('category-chart'), {
      type:'bar',
      data:{labels:c.map(r=>r.Category), datasets:[{label:'Revenue', data:c.map(r=>r.Revenue), backgroundColor:SERIES, borderRadius:5}]},
      options:{indexAxis:'y', responsive:true, maintainAspectRatio:false,
        scales:{x:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, y:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });
    document.getElementById('category-table').innerHTML = tableHTML(
      [{label:'Category'},{label:'Revenue', num:true},{label:'Orders', num:true},{label:'SKUs', num:true}],
      c.map(r => [r.Category, fmtMoney(r.Revenue), fmtNum(r.Orders), fmtNum(r.Products)])
    );
  };

  RENDERERS.inventory = function(){
    document.getElementById('inventory-note').innerHTML = '<b>Note:</b> ' + D.inventory.note;
    const k = D.inventory;
    document.getElementById('inventory-kpis').innerHTML =
      kpiCard('SKUs Tracked', fmtNum(k.total_skus), '', '') +
      kpiCard('Avg Days of Cover', k.avg_days_cover, 'across all SKUs', 'teal') +
      kpiCard('Estimated Stock Units', fmtNum(k.total_estimated_stock_units), 'modeled on-hand units', 'violet') +
      kpiCard('At Risk', fmtNum(k.status_summary['Stockout Risk']||0), 'SKUs under 7 days cover', 'coral');

    const s = k.status_summary;
    new Chart(document.getElementById('inventory-status'), {
      type:'doughnut',
      data:{labels:Object.keys(s), datasets:[{data:Object.values(s), backgroundColor:[PALETTE.coral, PALETTE.good||'#2E9C63', PALETTE.amber], borderWidth:0}]},
      options:{responsive:true, maintainAspectRatio:false, cutout:'62%',
        plugins:{legend:{position:'bottom'}}}
    });
  };

  RENDERERS.stockout = function(){
    const k = D.stockout;
    document.getElementById('stockout-kpis').innerHTML =
      kpiCard('SKUs at Risk', fmtNum(k.count), '', 'coral') +
      kpiCard('Share of Catalog', k.pct_of_skus+'%', 'of all active SKUs', '') +
      kpiCard('Action', 'Replenish', 'prioritize below list', 'teal');
    document.getElementById('stockout-table').innerHTML = tableHTML(
      [{label:'Code'},{label:'Product', wrap:true},{label:'Daily Demand', num:true},{label:'Days Cover', num:true},{label:'Est. Stock', num:true}],
      k.top_at_risk.map(r => [r.StockCode, r.Description, r.avg_daily_demand, r.days_of_cover, fmtNum(r.estimated_current_stock)])
    );
  };

  RENDERERS.overstock = function(){
    const k = D.overstock;
    document.getElementById('overstock-kpis').innerHTML =
      kpiCard('Overstocked SKUs', fmtNum(k.count), '', 'violet') +
      kpiCard('Share of Catalog', k.pct_of_skus+'%', 'of all active SKUs', '') +
      kpiCard('Slow Movers', fmtNum(k.slow_movers_no_recent_sale), 'no sale in 60+ days', 'coral');
    document.getElementById('overstock-table').innerHTML = tableHTML(
      [{label:'Code'},{label:'Product', wrap:true},{label:'Daily Demand', num:true},{label:'Days Cover', num:true},{label:'Est. Stock', num:true}],
      k.top_overstocked.map(r => [r.StockCode, r.Description, r.avg_daily_demand, r.days_of_cover, fmtNum(r.estimated_current_stock)])
    );
  };

  RENDERERS.promotion = function(){
    document.getElementById('promotion-note').innerHTML = '<b>Note:</b> ' + D.promotion.note;
    document.getElementById('promotion-kpis').innerHTML =
      kpiCard('Revenue from Promo Pricing', D.promotion.promo_share_of_revenue_pct+'%', 'of total revenue', 'amber');
    const rows = D.promotion.promo_vs_regular;
    const labels = rows.map(r => r.is_promo ? 'Promotional' : 'Regular Price');
    new Chart(document.getElementById('promotion-chart'), {
      type:'bar',
      data:{labels:['Revenue','Orders','Units'],
        datasets: rows.map((r,i) => ({
          label: r.is_promo ? 'Promotional' : 'Regular Price',
          data:[r.Revenue, r.Orders*100, r.Qty/10],
          backgroundColor: r.is_promo ? PALETTE.amber : PALETTE.navy,
          borderRadius:5
        }))
      },
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}}},
        plugins:{legend:{position:'top'}, tooltip:{callbacks:{label:(ctx)=>{
          const idx = ctx.dataIndex; const raw = rows[ctx.datasetIndex];
          const vals = [fmtMoney(raw.Revenue), fmtNum(raw.Orders)+' orders', fmtNum(raw.Qty)+' units'];
          return ctx.dataset.label + ': ' + vals[idx];
        }}}}}
    });
  };

  RENDERERS.seasonality = function(){
    const m = D.seasonality.by_month;
    new Chart(document.getElementById('season-month'), {
      type:'bar',
      data:{labels:Object.keys(m), datasets:[{label:'Revenue', data:Object.values(m), backgroundColor:PALETTE.amber, borderRadius:5}]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });
    const q = D.seasonality.by_quarter;
    new Chart(document.getElementById('season-quarter'), {
      type:'bar',
      data:{labels:Object.keys(q).map(x=>'Q'+x), datasets:[{label:'Revenue', data:Object.values(q), backgroundColor:PALETTE.teal, borderRadius:5}]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });
  };

  RENDERERS.forecast = function(){
    document.getElementById('forecast-note').innerHTML = '<b>Method:</b> ' + D.forecast.method + ' Trend direction: <b>' + D.forecast.trend_direction + '</b>.';
    const hist = D.forecast.historical;
    const fc = D.forecast.forecast_next_6m;
    const labels = hist.map(r=>r.YearMonth).concat(fc.map(r=>r.YearMonth));
    const histData = hist.map(r=>r.Revenue).concat(Array(fc.length).fill(null));
    const bridge = hist.length ? hist[hist.length-1].Revenue : null;
    const fcData = Array(hist.length-1).fill(null).concat([bridge]).concat(fc.map(r=>r.Forecast));
    new Chart(document.getElementById('forecast-chart'), {
      type:'line',
      data:{labels, datasets:[
        {label:'Actual Revenue', data:histData, borderColor:PALETTE.navy, backgroundColor:'rgba(42,67,132,.08)', fill:true, tension:.3, pointRadius:2},
        {label:'Forecast', data:fcData, borderColor:PALETTE.coral, borderDash:[6,4], tension:.3, pointRadius:2}
      ]},
      options:{responsive:true, maintainAspectRatio:false,
        scales:{y:{grid:gridOpt, ticks:{callback:v=>fmtMoney(v)}}, x:{grid:{display:false}, ticks:{maxRotation:60,minRotation:60}}},
        plugins:{legend:{position:'top', align:'end'}}}
    });
  };

  RENDERERS.customer = function(){
    const k = D.customer;
    document.getElementById('customer-kpis').innerHTML =
      kpiCard('Total Customers', fmtNum(k.total_customers), '', '') +
      kpiCard('Repeat Purchase Rate', k.repeat_purchase_rate_pct+'%', '', 'teal') +
      kpiCard('Avg Revenue / Customer', '£'+k.avg_revenue_per_customer.toFixed(0), '', 'violet') +
      kpiCard('One-Time Buyers', k.one_time_customers_pct+'%', 'of customer base', 'coral');

    document.getElementById('customer-table').innerHTML = tableHTML(
      [{label:'Customer ID'},{label:'Revenue', num:true},{label:'Orders', num:true},{label:'Recency (days)', num:true}],
      k.top_customers.map(r => [Math.round(r['Customer ID']), fmtMoney(r.Revenue), r.Orders, r.Recency_days])
    );

    const c = k.customers_by_country;
    new Chart(document.getElementById('customer-country'), {
      type:'bar',
      data:{labels:Object.keys(c), datasets:[{label:'Customers', data:Object.values(c), backgroundColor:PALETTE.violet, borderRadius:4}]},
      options:{indexAxis:'y', responsive:true, maintainAspectRatio:false,
        scales:{x:{grid:gridOpt}, y:{grid:{display:false}}},
        plugins:{legend:{display:false}}}
    });
  };

  RENDERERS.recommendation = function(){
    document.getElementById('reco-list').innerHTML = D.recommendation.summary_points.map((p,i) =>
      `<li class="reco-item"><span class="idx">${String(i+1).padStart(2,'0')}</span><span>${p}</span></li>`
    ).join('');
  };

  // ---------------- Init ----------------
  const initial = (location.hash || '#executive').replace('#','');
  showPage(document.getElementById('page-'+initial) ? initial : 'executive');
})();
